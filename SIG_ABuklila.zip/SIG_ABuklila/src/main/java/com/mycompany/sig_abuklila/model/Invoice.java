/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sig_abuklila.model;

import java.util.ArrayList;

/**
 *
 * @author Mohamed
 */
public class Invoice {
    
    private String customerName;
    private int invoiceNumber; 
    private String invoiceDate;
    private ArrayList<Line> InvoiceItems;

    public Invoice() {
        InvoiceItems = new ArrayList<>();
    }

    public Invoice(String customerName, int invoiceNumber, String invoiceDate) {
        this.customerName = customerName;
        this.invoiceNumber = invoiceNumber;
        this.invoiceDate = invoiceDate;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(int invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public ArrayList<Line> getInvoiceItems() {
        if (InvoiceItems == null) {
            InvoiceItems = new ArrayList<>();
        }
        return InvoiceItems;
    }

    public void setInvoiceItems(ArrayList<Line> InvoiceItems) {
        this.InvoiceItems = InvoiceItems;
    }
    
    public double getInvoiceTotal() {
        double invoiceTotal = 0.0;
        for (Line line : getInvoiceItems()) {
            invoiceTotal += line.getTotal();
        }
        return invoiceTotal;
    }
    
    /********* used to save file
     * @return  ************/
    public String convertToCSV() {
        return invoiceNumber + "," + invoiceDate + "," + customerName;
    }

    @Override
    public String toString() {
        return "Invoice{" + "customerName=" + customerName + ", invoiceNumber=" + invoiceNumber + ", invoiceDate=" + invoiceDate + ", InvoiceItems=" + InvoiceItems + '}';
    }   
   
}
