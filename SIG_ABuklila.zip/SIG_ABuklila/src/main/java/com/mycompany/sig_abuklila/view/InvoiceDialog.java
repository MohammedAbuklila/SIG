/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sig_abuklila.view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Mohamed
 */
public class InvoiceDialog extends JDialog {
    
    private final JLabel customerNameLabel;
    private JTextField customerNameField;
    private final JLabel invDateLabel;
    private JTextField invDateField;
    private JButton saveButton;
    private JButton cancelButton;
    
    public InvoiceDialog(InvoiceFrame frame) {

        setLayout(new GridLayout(3, 3));
        setTitle("New Invoice");
        setLocation(350, 250);

        customerNameLabel = new JLabel("Customer Name: ");
        customerNameField = new JTextField(20);

        invDateLabel = new JLabel("Invoice Date: ");
        invDateField = new JTextField(10);

        saveButton = new JButton("Save");
        saveButton.setActionCommand("saveNewInvoice");

        cancelButton = new JButton("Cancel");
        cancelButton.setActionCommand("cancelSavingNewInvoice");

        saveButton.addActionListener(frame.getController());
        cancelButton.addActionListener(frame.getController());

        add(customerNameLabel);
        add(customerNameField);
        add(invDateLabel);
        add(invDateField);
        add(saveButton);
        add(cancelButton);

        pack();
    }

    public JTextField getCustomerNameField() {
        return customerNameField;
    }

    public void setCustomerNameField(JTextField customerNameField) {
        this.customerNameField = customerNameField;
    }

    public JTextField getInvDateField() {
        return invDateField;
    }

    public void setInvDateField(JTextField invDateField) {
        this.invDateField = invDateField;
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public void setSaveButton(JButton saveButton) {
        this.saveButton = saveButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void setCancelButton(JButton cancelButton) {
        this.cancelButton = cancelButton;
    }

    @Override
    public String toString() {
        return "InvoiceDialog{" + "customerNameField=" + customerNameField + ", customerNameLabel=" + customerNameLabel + ", invDateField=" + invDateField + ", invDateLabel=" + invDateLabel + ", saveButton=" + saveButton + ", cancelButton=" + cancelButton + '}';
    }
    
    
    
    
}
