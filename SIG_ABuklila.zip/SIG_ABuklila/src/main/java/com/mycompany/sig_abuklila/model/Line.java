/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sig_abuklila.model;

/**
 *
 * @author Mohamed
 */
public class Line {
    
    private String itemName;
    private double itemPrice;
    private int count;
    private Invoice invoice;

    public Line() {
        invoice = new Invoice();
    }

    public Line(String itemName, double itemPrice, int count, Invoice invoice) {
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.count = count;
        this.invoice = invoice;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }

    public double getTotal() {
        return itemPrice * count;
    }

    /********** used to save file
     * @return  *************/
    public String converToCSV() {
        return invoice.getInvoiceNumber()+ "," + itemName + "," + itemPrice + "," + count;

    }
    
    @Override
    public String toString() {
        return "Line{" + "itemName=" + itemName + ", itemPrice=" + itemPrice + ", count=" + count + ", invoice=" + invoice + '}';
    }
    
  
    
}
