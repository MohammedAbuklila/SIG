/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sig_abuklila.view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author Mohamed
 */
public class LineDialog extends JDialog {
    
    private final JLabel itemNameLabel;
    private JTextField itemNameField;
    private final JLabel itemCountLabel;
    private JTextField itemCountField;
    private final JLabel itemPriceLabel;
    private JTextField itemPriceField;
    private JButton saveButton;
    private JButton cancelButton;

    public LineDialog(InvoiceFrame frame) {

        setLayout(new GridLayout(4, 2));
        setTitle("New Invoice Item");
//        setLocation(350, 250);

        itemNameLabel = new JLabel("Item Name");
        itemNameField = new JTextField(20);

        itemCountLabel = new JLabel("Item's Count");
        itemCountField = new JTextField(20);
        
        itemPriceLabel = new JLabel("Item's Price");
        itemPriceField = new JTextField(20);

        saveButton = new JButton("Save");
        saveButton.setActionCommand("saveNewInvoiceItem");

        cancelButton = new JButton("Cancel");
        cancelButton.setActionCommand("cancelSavingInvoiceItem");

        saveButton.addActionListener(frame.getController());
        cancelButton.addActionListener(frame.getController());

        add(itemNameLabel);
        add(itemNameField);
        add(itemCountLabel);
        add(itemCountField);
        add(itemPriceLabel);
        add(itemPriceField);
        add(saveButton);
        add(cancelButton);

        pack();
    }
    
    public JTextField getItemNameField() {
        return itemNameField;
    }

    public void setItemNameField(JTextField itemNameField) {
        this.itemNameField = itemNameField;
    }

    public JTextField getItemCountField() {
        return itemCountField;
    }

    public void setItemCountField(JTextField itemCountField) {
        this.itemCountField = itemCountField;
    }

    public JTextField getItemPriceField() {
        return itemPriceField;
    }

    public void setItemPriceField(JTextField itemPriceField) {
        this.itemPriceField = itemPriceField;
    }

    public JButton getSaveButton() {
        return saveButton;
    }

    public void setSaveButton(JButton saveButton) {
        this.saveButton = saveButton;
    }

    public JButton getCancelButton() {
        return cancelButton;
    }

    public void setCancelButton(JButton cancelButton) {
        this.cancelButton = cancelButton;
    }

    @Override
    public String toString() {
        return "LineDialog{" + "itemNameLabel=" + itemNameLabel + ", itemNameField=" + itemNameField + ", itemCountLabel=" + itemCountLabel + ", itemCountField=" + itemCountField + ", itemPriceLabel=" + itemPriceLabel + ", itemPriceField=" + itemPriceField + ", saveButton=" + saveButton + ", cancelButton=" + cancelButton + '}';
    }
    
  
    
}
